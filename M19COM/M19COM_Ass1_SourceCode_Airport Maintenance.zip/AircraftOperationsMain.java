import java.util.*;

/**
 * This class is used to test Operations methods
 * @author (enter your name here)
 * @version (date)
 */
public class AircraftOperationsMain
{
    public static void main(String[] args)
    {    
        // Print start-of-testing timestamp
        System.out.println("\n*** Begin testing on " + new Date());
                
        // Create new concrete class implementing AircraftList interface for testing
        // populate it with at least 25 aircraft objects...
        
        
        // Test implemented AircraftList methods add(), remove() and get()
        System.out.println("\n** Begin testing aircraftlist methods");
        
        // testing goes here...
        
        System.out.println("\n** Finish testing aircraftlist methods");
        
        
        // Test implemented AircraftList method sort()
        System.out.println("\n** Begin testing sort method");
        
        // testing goes here...

        System.out.println("\n*** Finish testing sort method");
        
        
        System.out.println("\n*** Finish testing on " + new Date());
    }
}
