// Exercise_1 for m19com Lab4
// Write the implementation according to contract
public class ArraySumTest 
{

	public int sum(int[] a) 
	{
    	// Precondition: a is not null
    	// Postcondition: Returns the sum of the elements of a

		return 0; // Replace by proper implementation!
   }

	public static void main(String args[]) 
	{     
		ArraySumTest arrayTester = new ArraySumTest();
		
		// A first example call
      int[] x = {8, 2, -3, 4, 5, -3, 9};
      System.out.println("The sum of elements of x is " + arrayTester.sum(x));

      // Your implementation has to deal with empty arrays, so this
      // should work fine
      int[] y = {};
      System.out.println("The sum of elements of y is " + arrayTester.sum(y));
	}
}
