import java.util.*;

/**
 * Class to represent a "playlist" of songs
 * @author Alkis Stavrinides
 * @version 1.2 - 30/1/12 (Exercise_5 for m19com Lab4)
 */
public class PlayList implements SongList
{
    /**
     * Constructor
     */
    public PlayList()
    {
    }
    
    /**
     * Get the song at a given position in the list
     * @param ...
     * @return ...
     */
    public Song get(int i)
    {
        return null;
    }
    
   /**
     * Add a given song to the list
     * @param ...
     * @return ...
     */
    public boolean add(Song song)
    {
        return false;
    }
    
	 
    /**
     * Remove a given song from the list
     * @param ...
     * @return ...
     */
    public boolean remove(Song song)
    {
        return false;
    }
    
	 
    /**
     * Add all songs from another song list 
     * @param ...
     * @return ...
     */
    public boolean merge(SongList list)
    {
        return false;
    }    
	   
    
    /**
     * Check if the list contains a given song
     * @return ...
     */
    public boolean contains(Song song)
    {
        return false;
    }
  
    
    /**
     * Find a song matching a given string
     * @param ...
     * @return ...
     */
    public Song find(String str)
    {
        return null;
    }
    
	 
    /**
     * Clear the list
     */
    public void clear()
    {
    }
    
	 
    /**
     * Get the size of the list (= number of songs)
     * @return ...
     */
    public int size()
    {
        return 0;
    }
	 
	 
	 /**
     * Get the size of the list (= number of songs)
     * @return ...
     */
	 public boolean sort()
	 {
	 		return false;
	 }
	 
    
    /**
     * Convert list to single string with \n after each song
     * @return ...
     */
    public String toString()
    {
        return null;
    }
}
